//contact
// Get the modal
var modal1 = document.getElementById("myModal1");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

function box() {
  modal1.style.display = "block";
}

function closeBox1() {
  modal1.style.display = "none";
}

//help
// Get the modal
var modal2 = document.getElementById("myModal2");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

function box_2() {
  modal2.style.display = "block";
}

function closeBox2() {
  modal2.style.display = "none";
}

//about
// Get the modal
var modal3 = document.getElementById("myModal3");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

function box_3() {
  modal3.style.display = "block";
}

function closeBox3() {
  modal3.style.display = "none";
}

