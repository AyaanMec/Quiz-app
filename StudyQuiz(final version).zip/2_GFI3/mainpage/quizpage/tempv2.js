const Q=["what is the capital of France?","who won the 2018 world cup?","Who invented the BALLPOINT PEN?","Which city is home to the Brandenburg Gate?",'Who is generally considered the inventor of the motor car?']
const A1=["Toronto","france","Biro Brothers","Vienna","Henry Ford"]
const B1=["Paris","Pessi","Waterman Brothers","Zurich","Karl Benz"]
const C1=["London","Croatia","Bicc Brothers","Berlin","Henry M. Leland"]
const D1=["Mumbai","Brazil","Write Brothers","Austria","Gottlieb Wilhelm Daimler"]
const quizContainer = document.getElementById('quiz');
const resultContainer = document.getElementById('result');
const submitButton = document.getElementById('submit');
const retryButton = document.getElementById('retry');

var questions = localStorage.getItem("question_aray");
var q = JSON.parse(questions);

var options1 = localStorage.getItem("q1options_array");
var ops1 = JSON.parse(options1);

var options2 = localStorage.getItem("q2options_array");
var ops2 = JSON.parse(options2);

var options3 = localStorage.getItem("q3options_array");
var ops3 = JSON.parse(options3);

var options4 = localStorage.getItem("q4options_array");
var ops4 = JSON.parse(options4);

var options5 = localStorage.getItem("q5options_array");
var ops5 = JSON.parse(options5);

var answers = localStorage.getItem("answers_array");
var ans = JSON.parse(answers);
console.log(ans);

PresentQ=0
Score=0
const incorrectAns=[]
// function start(){
//     var maxMinutes = localStorage.getItem("timer");
//     var maxSeconds = maxMinutes * 60;
//     var currentSeconds = 0;

//     setInterval(time, 1000);

//     function time() {
//         if (currentSeconds < maxSeconds) {
//             currentSeconds++;

//             var remainingSeconds = maxSeconds - currentSeconds;
//             var minutes = Math.floor(remainingSeconds / 60);
//             var seconds = remainingSeconds % 60;

//             var formattedTime = padNumber(minutes) + ':' + padNumber(seconds);
//             document.getElementById('timer').innerText = formattedTime;
//         } else {
//             // Timer reached the maximum value, you can perform any action here
//             alert("Timer reached the maximum value!");
//             clearInterval();
//         }
//     }

//     function padNumber(number) {
//         return (number < 10 ? '0' : '') + number;
//     }

//     document.getElementById("quiz").style.display = "block";
//     document.getElementById("start").style.display = "none";
//     document.getElementById("submit").style.display = "block";
//     displayQ();

//     document.getElementById("quiz").style.display= "block";
//     document.getElementById("start").style.display= "none";
//     document.getElementById("submit").style.display= "block";
//     displayQ()
// }

function start() {
    var maxMinutes = localStorage.getItem("timer");
    var maxSeconds = maxMinutes * 60;
    var currentSeconds = 0;

    // Set up the timer interval
    var timerInterval = setInterval(time, 1000);

    function time() {
        if (currentSeconds < maxSeconds) {
            currentSeconds++;

            var remainingSeconds = maxSeconds - currentSeconds;
            var minutes = Math.floor(remainingSeconds / 60);
            var seconds = remainingSeconds % 60;

            var formattedTime = padNumber(minutes) + ':' + padNumber(seconds);
            document.getElementById('timer').innerText = formattedTime;
        } else {
            // Timer reached the maximum value
            clearInterval(timerInterval);
            alert("Timer reached the maximum value! Quiz is now disabled. Go back to home page to check scores.");
            // Disable the page (you can customize this part)
            disablePage();
        }
    }

    function padNumber(number) {
        return (number < 10 ? '0' : '') + number;
    }

    function disablePage() {
        // Example: Disable all input elements on the page
        var inputElements = document.getElementsByTagName("input");
        for (var i = 0; i < inputElements.length; i++) {
            inputElements[i].disabled = true;
        }

        // You can customize this part based on your page structure
    }

    document.getElementById("quiz").style.display = "block";
    document.getElementById("start").style.display = "none";
    document.getElementById("submit").style.display = "block";
    displayQ();
}
function displayQ(){

    var color = localStorage.getItem("color");
    document.body.style.backgroundColor = color; 
    

    quiz1.innerHTML= "1. " + q[0];
    document.getElementById('A1').nextSibling.textContent = ops1[0];
    document.getElementById('B1').nextSibling.textContent = ops1[1];
    document.getElementById('C1').nextSibling.textContent = ops1[2];
    document.getElementById('D1').nextSibling.textContent = ops1[3];
    
    quiz2.innerHTML= "2. " + q[1]
    document.getElementById('A2').nextSibling.textContent = ops2[0];
    document.getElementById('B2').nextSibling.textContent = ops2[1];
    document.getElementById('C2').nextSibling.textContent = ops2[2];
    document.getElementById('D2').nextSibling.textContent = ops2[3];
   
    quiz3.innerHTML= "3. " + q[2]
    document.getElementById('A3').nextSibling.textContent = ops3[0];
    document.getElementById('B3').nextSibling.textContent = ops3[1];
    document.getElementById('C3').nextSibling.textContent = ops3[2];
    document.getElementById('D3').nextSibling.textContent = ops3[3];
   
    quiz4.innerHTML= "4. " + q[3]
    document.getElementById('A4').nextSibling.textContent = ops4[0];
    document.getElementById('B4').nextSibling.textContent = ops4[1];
    document.getElementById('C4').nextSibling.textContent = ops4[2];
    document.getElementById('D4').nextSibling.textContent = ops4[3];

    quiz5.innerHTML= "5. " + q[4]
    document.getElementById('A5').nextSibling.textContent = ops5[0];
    document.getElementById('B5').nextSibling.textContent = ops5[1];
    document.getElementById('C5').nextSibling.textContent = ops5[2];
    document.getElementById('D5').nextSibling.textContent = ops5[3];

    add_image();
    
   
}

function add_image(x){

    document.getElementById("image1").setAttribute("src" , localStorage.getItem("link1"));
    document.getElementById("image2").setAttribute("src" , localStorage.getItem("link2"));
    document.getElementById("image3").setAttribute("src" , localStorage.getItem("link3"));
    document.getElementById("image4").setAttribute("src" , localStorage.getItem("link4"));
    document.getElementById("image5").setAttribute("src" , localStorage.getItem("link5"));
}



function submit(){

    document.getElementById("done").innerHTML="Go back to the home page and click scores"
    var score = 0;

    selectedChoice1 = document.querySelector('input[name="choice1"]:checked').value;
    selectedChoice2 = document.querySelector('input[name="choice2"]:checked').value;
    selectedChoice3 = document.querySelector('input[name="choice3"]:checked').value;
    selectedChoice4 = document.querySelector('input[name="choice4"]:checked').value;
    selectedChoice5 = document.querySelector('input[name="choice5"]:checked').value;

    choicearray = [selectedChoice1,selectedChoice2,selectedChoice3,selectedChoice4,selectedChoice5]
    console.log(choicearray);
 
    if(selectedChoice1 == ans[0]){score++};
    if(selectedChoice2 == ans[1]){score++};
    if(selectedChoice3 == ans[2]){score++};
    if(selectedChoice4 == ans[3]){score++};
    if(selectedChoice5 == ans[4]){score++};

    localStorage.setItem("score", score);
    
}
