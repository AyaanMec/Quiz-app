function display_score(){
    var score = localStorage.getItem("score");
    document.getElementById("scoredisplay").innerHTML = "Final Score: " + score + "/5";
}