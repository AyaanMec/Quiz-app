function setbgcolor(value){

    var c = document.body.style
    var color;

    if( value == 1 ){
        c.backgroundColor = "#45FFCA";
        color = "#45FFCA";
    } 
    else if ( value == 2){
        c.backgroundColor = "#E50914"; 
        color = "#E50914"
    }
    else if ( value == 3){
        c.backgroundColor = "#003399";
        color = "#003399"
    }
    else if ( value == 4){
        c.backgroundColor = "#F86F03"
        color = "#F86F03"
    }

    globalThis.color;
    localStorage.setItem("color", color);
}

function timer(){
    var timer = document.getElementById("timer_input").value;
    var p =  document.getElementById("set");

    

    if(timer > 0 ){

        p.innerHTML = "Timer set for: " + timer + " mins";
        localStorage.setItem("timer",timer);
        
    }
    else if ( timer == 0 || timer < 0) {
        p.innerHTML = "No time limit";
    }

}

function add_image(x){
    var link = prompt("Enter link for the image:");
    
    if (x==1){
        localStorage.setItem("link1",link);
        document.getElementById("added_image1").style.display = "block";
        document.getElementById("image1").setAttribute("src" , link);
    }
    else if(x==2){
        localStorage.setItem("link2",link);
        document.getElementById("added_image2").style.display = "block";
        document.getElementById("image2").setAttribute("src" , link);
    }
    else if(x==3){
        localStorage.setItem("link3",link);
        document.getElementById("added_image3").style.display = "block";
        document.getElementById("image3").setAttribute("src" , link);
    }
    else if(x==4){
        localStorage.setItem("link4",link);
        document.getElementById("added_image4").style.display = "block";
        document.getElementById("image4").setAttribute("src" , link);
    }
    else if(x==5){
        localStorage.setItem("link5",link);
        document.getElementById("added_image5").style.display = "block";
        document.getElementById("image5").setAttribute("src" , link);
    }
}

function saveanswer(q,o){

    if(q == 1 && o==1 ){
        globalThis.ans1 = document.getElementById("option_a1").value
        globalThis.Ans1 = "A1";
    }
    else if(q==1&& o==2){
        globalThis.ans1 = document.getElementById("option_b1").value
        globalThis.Ans1 = "B1";
    }
    else if(q==1&& o==3){
        globalThis.ans1 = document.getElementById("option_c1").value
        globalThis.Ans1 = "C1";
    }
    else if(q==1&& o==4){
        globalThis.ans1 = document.getElementById("option_d1").value
        globalThis.Ans1 = "D1";
    }

    if(q == 2 && o==1 ){
        globalThis.ans2 = document.getElementById("option_a2").value
        globalThis.Ans2 = "A2";
    }
    else if(q==2&& o==2){
        globalThis.ans2 = document.getElementById("option_b2").value
        globalThis.Ans2 = "B2";
    }
    else if(q==2&& o==3){
        globalThis.ans2 = document.getElementById("option_c2").value
        globalThis.Ans2 = "C2";

    }
    else if(q==2&& o==4){
        globalThis.ans2 = document.getElementById("option_d2").value
        globalThis.Ans2 = "D2";

    }

    if(q == 3 && o==1 ){
        globalThis.ans3 = document.getElementById("option_a3").value
        globalThis.Ans3 = "A3";

    }
    else if(q==3&& o==2){
        globalThis.ans3 = document.getElementById("option_b3").value
        globalThis.Ans3 = "B3";
    }
    else if(q==3&& o==3){
        globalThis.ans3 = document.getElementById("option_c3").value
        globalThis.Ans3 = "C3";
    }
    else if(q==3&& o==4){
        globalThis.ans3 = document.getElementById("option_d3").value
        globalThis.Ans3 = "D3";
    }

    if(q == 4 && o==1 ){
        globalThis.ans4 = document.getElementById("option_a4").value
        globalThis.Ans4 = "A4";
    }
    else if(q==4&& o==2){
        globalThis.ans4 = document.getElementById("option_b4").value
        globalThis.Ans4 = "B4";
    }
    else if(q==4&& o==3){
        globalThis.ans4 = document.getElementById("option_c4").value
        globalThis.Ans4 = "C4";
    }
    else if(q==4&& o==4){
        globalThis.ans4 = document.getElementById("option_d4").value
        globalThis.Ans4 = "D4";
    }

    if(q == 5 && o==1 ){
        globalThis.ans5 = document.getElementById("option_a5").value
        globalThis.Ans5 = "A5";
    }
    else if(q==5&& o==2){
        globalThis.ans5 = document.getElementById("option_b5").value
        globalThis.Ans5 = "B5";
    }
    else if(q==5&& o==3){
        globalThis.ans5 = document.getElementById("option_c5").value
        globalThis.Ans5 = "C5";
    }
    else if(q==5&& o==4){
        globalThis.ans5 = document.getElementById("option_d5").value
        globalThis.Ans5 = "D5";
    }



    document.getElementById("correctanswer1").innerHTML="Correct answer: " + ans1;
    document.getElementById("correctanswer2").innerHTML="Correct answer: " + ans2;
    document.getElementById("correctanswer3").innerHTML="Correct answer: " + ans3;
    document.getElementById("correctanswer4").innerHTML="Correct answer: " + ans4;
    document.getElementById("correctanswer5").innerHTML="Correct answer: " + ans5;

}

function add_question(x){
    if (x==1){
        globalThis.q1 = document.getElementById("questionbox1").value;
        globalThis.opa1 = document.getElementById("option_a1").value;
        globalThis.opb1 = document.getElementById("option_b1").value;
        globalThis.opc1 = document.getElementById("option_c1").value;
        globalThis.opd1 = document.getElementById("option_d1").value;
    
        document.getElementById("q1").innerHTML = "1. " + q1;
        document.getElementById("opa1").innerHTML = "a. " + opa1;
        document.getElementById("opb1").innerHTML = "b. " + opb1;
        document.getElementById("opc1").innerHTML = "c. " + opc1; 
        document.getElementById("opd1").innerHTML = "d. " + opd1;
        document.getElementById("lighttext1").style.display="none";

    }
    else if(x==2){
        globalThis.q2 = document.getElementById("questionbox2").value;
        globalThis.opa2 = document.getElementById("option_a2").value;
        globalThis.opb2 = document.getElementById("option_b2").value;
        globalThis.opc2 = document.getElementById("option_c2").value;
        globalThis.opd2 = document.getElementById("option_d2").value;
    
        document.getElementById("q2").innerHTML = "2. " + q2;
        document.getElementById("opa2").innerHTML = "a. " + opa2;
        document.getElementById("opb2").innerHTML = "b. " + opb2;
        document.getElementById("opc2").innerHTML = "c. " + opc2; 
        document.getElementById("opd2").innerHTML = "d. " + opd2;
        document.getElementById("lighttext2").style.display="none";
        // document.getElementById("image_button").style.display="none";
    }
    else if(x==3){
        globalThis.q3 = document.getElementById("questionbox3").value;
        globalThis.opa3 = document.getElementById("option_a3").value;
        globalThis.opb3 = document.getElementById("option_b3").value;
        globalThis.opc3 = document.getElementById("option_c3").value;
        globalThis.opd3 = document.getElementById("option_d3").value;
    
        document.getElementById("q3").innerHTML = "3. " + q3;
        document.getElementById("opa3").innerHTML = "a. " + opa3;
        document.getElementById("opb3").innerHTML = "b. " + opb3;
        document.getElementById("opc3").innerHTML = "c. " + opc3; 
        document.getElementById("opd3").innerHTML = "d. " + opd3;
        document.getElementById("lighttext3").style.display="none";
        // document.getElementById("image_button").style.display="none";
    }
    else if(x==4){
        globalThis.q4 = document.getElementById("questionbox4").value;
        globalThis.opa4 = document.getElementById("option_a4").value;
        globalThis.opb4 = document.getElementById("option_b4").value;
        globalThis.opc4 = document.getElementById("option_c4").value;
        globalThis.opd4 = document.getElementById("option_d4").value;
    
        document.getElementById("q4").innerHTML = "4. " + q4;
        document.getElementById("opa4").innerHTML = "a. " + opa4;
        document.getElementById("opb4").innerHTML = "b. " + opb4;
        document.getElementById("opc4").innerHTML = "c. " + opc4; 
        document.getElementById("opd4").innerHTML = "d. " + opd4;
        document.getElementById("lighttext4").style.display="none";
        // document.getElementById("image_button").style.display="none";
    }
    else if(x==5){
        globalThis.q5 = document.getElementById("questionbox5").value;
        globalThis.opa5 = document.getElementById("option_a5").value;
        globalThis.opb5 = document.getElementById("option_b5").value;
        globalThis.opc5 = document.getElementById("option_c5").value;
        globalThis.opd5 = document.getElementById("option_d5").value;
    
        document.getElementById("q5").innerHTML = "5. " + q5;
        document.getElementById("opa5").innerHTML = "a. " + opa5;
        document.getElementById("opb5").innerHTML = "b. " + opb5;
        document.getElementById("opc5").innerHTML = "c. " + opc5; 
        document.getElementById("opd5").innerHTML = "d. " + opd5;
        document.getElementById("lighttext5").style.display="none";
        // document.getElementById("image_button").style.display="none";
    }
}

function savechanges(){

    document.getElementById("saved").innerHTML="Changes Saved! <br><hr id='hr'><br> Go back to the home page and click take quiz to take quiz"
    var question_array = [q1,q2,q3,q4,q5];

    var q1options_array = [opa1,opb1,opc1,opd1];
    var q2options_array = [opa2,opb2,opc2,opd2];
    var q3options_array = [opa3,opb3,opc3,opd3];
    var q4options_array = [opa4,opb4,opc4,opd4];
    var q5options_array = [opa5,opb5,opc5,opd5];
    var answers_array = [Ans1 ,Ans2 ,Ans3 ,Ans4 ,Ans5];



    localStorage.setItem("question_aray", JSON.stringify(question_array));

    localStorage.setItem("q1options_array", JSON.stringify(q1options_array));
    localStorage.setItem("q2options_array", JSON.stringify(q2options_array));
    localStorage.setItem("q3options_array", JSON.stringify(q3options_array));
    localStorage.setItem("q4options_array", JSON.stringify(q4options_array));
    localStorage.setItem("q5options_array", JSON.stringify(q5options_array));
    localStorage.setItem("answers_array", JSON.stringify(answers_array));


}
